/* app_main.c ---------------------------------------------------------------*/
#include "cmsis_os2.h"
#include "main.h"                  /* SystemClock_Config gerekiyorsa        */
#include "RTE_Components.h"
#include  CMSIS_device_header
#include "LCD.h"
#include <stdio.h>
#include <stdbool.h>
#include "stm32f4xx_it.h"
#include <string.h>
#include "Si7021_driver.h"

extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim1; // Timer tanimi (CubeMX'te yapilandirdiysan)
extern TIM_HandleTypeDef htim1; // Timer tanimi (CubeMX'te yapilandirdiysan)
extern RTC_TimeTypeDef sTime;
extern RTC_DateTypeDef sDate;
extern RTC_HandleTypeDef hrtc;
extern bool isAlarmOn;
char line1[32], line2[32];
extern bool isEmergency;
extern void set_pwm_freq(float freq); // Prototip
extern bool isTimerStarted;
extern RTC_TimeTypeDef startTime;
uint32_t elapsedSeconds;
extern UART_HandleTypeDef huart2;
float tempres = 0;
int tempreturn = 0;
int vddreturn = 10;
Si7021_measurement_type_t tempsi7021;
/* -------- LED blink thread ------------------------------------------------*/
//__NO_RETURN static void led_blink_thread (void *argument)
//{
//  (void)argument;
//  for (;;) {
//    HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
//    osDelay(1000);                                   /* 100 ms                  */
//  }
//}
/* -------- LED blink thread ------------------------------------------------*/
__NO_RETURN static void timer_thread (void *argument)
{
  (void)argument;
  for (;;) {
		if(isTimerStarted){
		RTC_TimeTypeDef currentTime;
    HAL_RTC_GetTime(&hrtc, &currentTime, RTC_FORMAT_BIN); // Mevcut zamani al

    // Ge?en s?reyi hesapla
    elapsedSeconds = (currentTime.Hours * 3600 + currentTime.Minutes * 60 + currentTime.Seconds) -
                              (startTime.Hours * 3600 + startTime.Minutes * 60 + startTime.Seconds);
		}
                                   /* 100 ms                  */
  }
}

/* -------- SI7021 ----------------------------------------------------------*/

__NO_RETURN static void si7021 (void *argument)
{
  (void)argument;

  for (;;) {
		
    tempreturn = r_single_Si7021(&tempres , tempsi7021);		
		osDelay(1000);
		//vddreturn = VDD_warning_Si7021();
		if (tempres > 0)
		{
			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, 1);
		}
  }
}



/* -------- UART thread ------------------------------------------------*/
__NO_RETURN static void uart_thread (void *argument)
{
  (void)argument;
	const char *msg = "as\r\n";

  for (;;) {
	HAL_UART_Transmit(&huart2, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);
  osDelay(1000); // 1 saniye bekle, CPU'yu yormamak i�in

  }
}
/* -------- Alarm thread ------------------------------------------------*/
__NO_RETURN static void alarm_thread (void *argument)
{
  (void)argument;

  for (;;) {
		if(isAlarmOn){
			HAL_GPIO_WritePin(alarm_output_GPIO_Port, alarm_output_Pin, 1);
		}

  }
}
/* -------- Emergency thread ------------------------------------------------*/
__NO_RETURN static void emergency_thread(void *argument)
{
    (void)argument;
    
    const float freq_min = 1000.0f;
    const float freq_max = 2800.0f;
    const float freq_step = 100.0f;
    const uint32_t sweep_delay = 20; // ms, daha y�ksek olursa daha yavas degisir

    // PWM sinyali s�rekli a�ik kalsin
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
		int count = 0;

    while (1)
    {
        if (isEmergency)
        {
					if(count<5){
						 // Artan frekans (ambulans sireni gibi)
                for (float freq = freq_min; freq <= freq_max; freq += freq_step)
                {
                    set_pwm_freq(freq);
                    osDelay(sweep_delay);
                }

                // Azalan frekans
                for (float freq = freq_max; freq >= freq_min; freq -= freq_step)
                {
                    set_pwm_freq(freq);
                    osDelay(sweep_delay);
                }
								
								count++;
					}else{
						__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 0);  // Duty cycle = 0 ? sessizlik
						isEmergency = false;
					}

        }else{
					count = 0;
					__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 0);  // Duty cycle = 0 ? sessizlik
					isEmergency = false;
				}


        osDelay(100); // CPU'yu bosuna mesgul etme, idle'da bekle
    }
}


/* -------- LcD ------------------------------------------------*/
__NO_RETURN static void lcd_thread (void *argument)
{
  (void)argument;
	lcd_init(_LCD_4BIT, _LCD_FONT_5x8, _LCD_2LINE);

	
	while(1){

		// Satir 1: Elapsed Time
		if(isEmergency){
			snprintf(line1, sizeof(line1), "!!! HELP !!!");
			snprintf(line2, sizeof(line2), "!!! !!! !!!");

			lcd_print_cleaned(1, 1, line1);		
			lcd_print_cleaned(2, 1, line2);
		}else if(isTimerStarted){
			snprintf(line1, sizeof(line1), "%d s", elapsedSeconds);
			lcd_print_cleaned(1, 1, line1);
			
			snprintf(line2, sizeof(line2), "");
			lcd_print_cleaned(2, 1, line2);
		}else if(isAlarmOn){
			snprintf(line1, sizeof(line1), "!!! ALARM !!!");
			snprintf(line2, sizeof(line2), "!!! !!! !!!");

			lcd_print_cleaned(1, 1, line1);		
			lcd_print_cleaned(2, 1, line2);
		}
		else{
			HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
			HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);
			snprintf(line1, sizeof(line1), "%d:%d:%d  %d", sTime.Hours, sTime.Minutes, sTime.Seconds, tempreturn);
			snprintf(line2, sizeof(line2), "%d/%d/%d", sDate.Date, sDate.Month, sDate.Year);

			lcd_print_cleaned(1, 1, line1);		
			lcd_print_cleaned(2, 1, line2);		
		}
		osDelay(1000);

	}
}

/* -------- Uygulama ana giris ---------------------------------------------*/
void app_main (void *arg)
{
  (void)arg;
	

	osThreadNew(emergency_thread, NULL, NULL);
//  osThreadNew(led_blink_thread,    NULL, NULL);
  osThreadNew(lcd_thread, NULL, NULL);
	osThreadNew(timer_thread, NULL, NULL);
	osThreadNew(uart_thread, NULL, NULL);
	osThreadNew(alarm_thread, NULL, NULL);
	
  osThreadExit();                                    /* Ana thread biter      */
}
